import MongoConnection from "./mongo-connection";

export default async function seed() {
    try {
        const conn = await MongoConnection.getInstance();        
        const db = conn.db("devweb");
        const news = db.collection("news");
        if (await news.countDocuments() === 0) {
            await news.insertMany([
                {
                    title: "Notícia Qualquer 1",
                    headline: "Olha essa notícia no que deu!!!",
                    content: "Lorem Ipsum",
                    author: "Tião",
                },
                {
                    title: "Notícia Qualquer 2",
                    headline: "Olha essa notícia no que deu!!!",
                    content: "Lorem Ipsum",
                    author: "Tião",
                },          
                {
                    title: "Notícia Qualquer 3",
                    headline: "Olha essa notícia no que deu!!!",
                    content: "Lorem Ipsum",
                    author: "Tião",
                },     
                {
                    title: "Notícia Qualquer 4",
                    headline: "Olha essa notícia no que deu!!!",
                    content: "Lorem Ipsum",
                    author: "Tião",
                },     
                {
                    title: "Notícia Qualquer 5",
                    headline: "Olha essa notícia no que deu!!!",
                    content: "Lorem Ipsum",
                    author: "Tião",
                },            
            ]);
        }
    } catch (error) {
        console.log("Erro ao conectar com o banco de dados!");
    }
}