import { MongoClient } from "mongodb";

export default class MongoConnection {

    private static conn: MongoClient;

    public static async getInstance(): Promise<MongoClient> {
        if (!this.conn) {
            await this.openConnection();
        }
        return this.conn;
    }

    public static async openConnection(): Promise<void> {
        const client: MongoClient = new MongoClient("mongodb://localhost:27017/");
        const conn = await client.connect();
        console.log("Conexão com o banco de dados estabelecida!");

        const close = () => {
            this.conn.close();
            console.log("Conexão com o banco de dados encerrada!");
            process.exit();
        }

        process.on("SIGINT", close);
        process.on("SIGTERM", close);

        this.conn = conn;
    }

}