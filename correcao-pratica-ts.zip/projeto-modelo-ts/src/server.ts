import express, { Request, Response } from "express";
import cors from "cors";
import MongoConnection from "./db/mongo-connection";
import { ObjectId } from "mongodb";

export default function server() {
    const port = process.env.WS_PORT ? 
        parseInt(process.env.WS_PORT) :
        3000;

    const app = express();

    app.use(cors());
    app.use(express.json());

    app.get("/news", async (req: Request, res: Response) => {
        const { author } = req.query;

        const conn = await MongoConnection.getInstance();
        const db = conn.db("devweb");
        const news = db.collection("news");
        res.status(200).json(await news.find(
            typeof author === "string" ? { author } : {}
        ).toArray());
    });

    app.post("/news", async (req: Request, res: Response) => {
        const newsBody = req.body;
        const conn = await MongoConnection.getInstance();
        const db = conn.db("devweb");
        const news = db.collection("news");
        await news.insertOne(newsBody);
        res.status(201).json(newsBody);
    });

    app.put("/news/:id", async (req: Request, res: Response) => {
        // const id = req.params.id;
        const { id } = req.params;
        const newsBody = req.body;
        const objectId = new ObjectId(id);
        const conn = await MongoConnection.getInstance();
        const db = conn.db("devweb");
        const news = db.collection("news");
        if (await news.countDocuments({_id: objectId}) === 0) {
            res.status(404).json({
                message: "Não existe notícia com esse id"
            });
            return;
        }
        await news.updateOne({_id: objectId}, { $set: newsBody });
        res.status(200).json(await news.findOne({_id: objectId}));
    });

    app.delete("/news/:id", async (req: Request, res: Response) => {
        // const id = req.params.id;
        const { id } = req.params;
        const newsBody = req.body;
        const objectId = new ObjectId(id);
        const conn = await MongoConnection.getInstance();
        const db = conn.db("devweb");
        const news = db.collection("news");
        if (await news.countDocuments({_id: objectId}) === 0) {
            res.status(404).json({
                message: "Não existe notícia com esse id"
            });
            return;
        }
        await news.deleteOne({_id: objectId});
        res.status(204).send("");
    });    
    
    app.listen(port, () => {
        console.log(`Servidor sendo executado na porta ${port}`);        
    });
}