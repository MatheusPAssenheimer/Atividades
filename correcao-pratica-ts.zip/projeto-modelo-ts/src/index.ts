import seed from "./db/seed";
import server from "./server";

(async () => {
    await seed();
    server();
})();
